# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['archery_person']

package_data = \
{'': ['*']}

install_requires = \
['archery-auth @ git+https://github.com/archeryhq/archery-auth.git@main',
 'archery-cookie @ git+https://github.com/archeryhq/archery-cookie.git@main',
 'archery-secret @ git+https://github.com/archeryhq/archery-secret.git@main',
 'python-dotenv>=0.17.0,<0.18.0']

setup_kwargs = {
    'name': 'archery-person',
    'version': '0.1.0',
    'description': 'Authorization and session.',
    'long_description': '# Archery Person\nAuthorization and session manager.\n\n[Github](https://github.com/archeryhq/archery-person)\n\n[Pipy](https://pypi.org/project/archery-person/)',
    'author': 'Enio Climaco Sales Junior',
    'author_email': 'eniocsjunior@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/archeryhq/archery-person',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
