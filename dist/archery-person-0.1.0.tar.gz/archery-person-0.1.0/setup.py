# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['archery_person']

package_data = \
{'': ['*']}

install_requires = \
['SQLAlchemy>=1.4.3,<2.0.0',
 'argon2-cffi>=20.1.0,<21.0.0',
 'cryptography>=3.4.7,<4.0.0',
 'psycopg2>=2.8.6,<3.0.0',
 'python-dotenv>=0.16.0,<0.17.0',
 'redis>=3.5.3,<4.0.0']

setup_kwargs = {
    'name': 'archery-person',
    'version': '0.1.0',
    'description': 'Authorization and session.',
    'long_description': None,
    'author': 'Enio Climaco Sales Junior',
    'author_email': 'eniocsjunior@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
