# Archery Person
Authorization and session manager.

[Github](https://github.com/archeryhq/archery-person)

[Pipy](https://pypi.org/project/archery-person/)